package missionControl;
import Utilis.*;

import java.io.Console;

public class MissionCOntrol {
    Client client = new Client();
    Server server = new Server();
    public  void  acciss (String[] args){
       Console console =System.console();

        System.out.println("Select 1. to send or 2 To Receive");
        int a= Integer.parseInt(console.readLine());
        switch (a){
            case 1:
                getServer();
            case 2:
                getClient();
        }
    }

    public  Server getServer() {
        return server;
    }

    public Client getClient() {
        return client;
    }
}
