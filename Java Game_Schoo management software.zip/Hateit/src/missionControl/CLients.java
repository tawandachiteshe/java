package missionControl;

public class CLients {

    public static void main(String[] args){
        MissionCOntrol missionCOntrol = new MissionCOntrol();
        missionCOntrol.acciss(args);
    }
}
