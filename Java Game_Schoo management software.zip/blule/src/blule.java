public class blule {

    public static void main(String[] tawanda){
      int blessed = 0;
      while(blessed>10){
          
      }

    }
}
