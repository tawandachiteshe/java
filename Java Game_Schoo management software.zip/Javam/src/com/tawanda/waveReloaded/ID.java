package com.tawanda.waveReloaded;

public enum ID {
    Player(),
    Enemy(),
    Enemy2,
    IntelligentAIEnemy(),
    Boss1(),
    Boss1bullets(),
    Trail()
}
