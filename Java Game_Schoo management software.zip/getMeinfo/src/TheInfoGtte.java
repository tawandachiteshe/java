
import java.net.*;
import java.io.*;



public class TheInfoGtte {


    public static void main(String[] args)throws IOException{
        URLConnection urlConnection;
        URLConnection.

        String uri="127.0.0.1";
        Inet4Address inet4Address = (Inet4Address) Inet4Address.getByName(uri);
        URL url = new URL("http://"+uri);
        url.openConnection();
        String urL = url.getPath();
        String net = inet4Address.getHostAddress();
        urlConnection.getURL();
        urlConnection.connect();
        System.out.println(net);

    }

}
