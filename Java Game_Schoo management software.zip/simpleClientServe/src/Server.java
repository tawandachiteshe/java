import javax.swing.*;
import javax.swing.plaf.DimensionUIResource;
import java.awt.*;

import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class Server {


    public static void main(String args[]){
        int main[] = new int[10];
        JFrame jFrame = new JFrame("HELLO");
        jFrame.setMaximumSize(new DimensionUIResource(123,123));
        jFrame.setPreferredSize(new DimensionUIResource(123,123));
        jFrame.setMinimumSize(new DimensionUIResource(640,320));
        jFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        jFrame.setResizable(false);

        jFrame.setVisible(true);
        JButton jButton = new JButton("add");
        jButton.setSize(100,100);
        jButton.setSize(new DimensionUIResource(100,100));
        jButton.setAlignmentX(128);
        jButton.setAlignmentY(90);

                jFrame.add(jButton);
    }
}
