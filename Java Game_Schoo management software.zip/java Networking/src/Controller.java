public class Controller {

    public static void  main(String[] args)throws  Exception{
        startserver SS =    new startserver();
        SS.startServer(9090);
    }
}
