import com.sun.net.httpserver.*;
import com.sun.security.ntlm.Server;
import jdk.nashorn.internal.parser.JSONParser;
import sun.net.www.http.HttpCapture;
import sun.net.www.http.HttpCaptureInputStream;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.util.concurrent.Executor;

public class startserver {

    public static void startServer(int socket) throws Exception {



        InetSocketAddress socketAddress = new InetSocketAddress(socket);
        final HttpServer httpServer = HttpServer.create(socketAddress,9);



        HttpExchange exchange =new HttpExchange() {
            @Override
            public Headers getRequestHeaders() {
                return null;
            }

            @Override
            public Headers getResponseHeaders() {
                return null;
            }

            @Override
            public URI getRequestURI() {
                return null;
            }

            @Override
            public String getRequestMethod() {
                return null;
            }

            @Override
            public HttpContext getHttpContext() {
                return exchange.getHttpContext();
            }

            @Override
            public void close() {

            }

            @Override
            public InputStream getRequestBody() {
                return null;
            }

            @Override
            public OutputStream getResponseBody() {
                return null;
            }

            @Override
            public void sendResponseHeaders(int i, long l) throws IOException {

            }

            @Override
            public InetSocketAddress getRemoteAddress() {
                return null;
            }

            @Override
            public int getResponseCode() {
                return 0;
            }

            @Override
            public InetSocketAddress getLocalAddress() {
                return null;
            }

            @Override
            public String getProtocol() {
                return null;
            }

            @Override
            public Object getAttribute(String s) {
                return null;
            }

            @Override
            public void setAttribute(String s, Object o) {

            }

            @Override
            public void setStreams(InputStream inputStream, OutputStream outputStream) {
                try {
                    outputStream.write(12);
                    inputStream.read();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public HttpPrincipal getPrincipal() {
                return null;
            }
        };

        HttpHandler httpHandler = new HttpHandler() {
            @Override
            public void handle(HttpExchange httpExchange) throws IOException{
                httpExchange = exchange;
            }
        };
        httpServer.createContext("/index.html",httpHandler);
        httpServer.start();
        System.out.printf(httpServer.getAddress()+"");
        System.out.println(exchange.getHttpContext());
    }


    public void responce() throws Exception {
        Socket socket = new Socket("127.0.0.1", 9090);

        DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());

    }
}