package networking;
import java.util.*;
import java.util.concurrent.Callable;
import java.io.IOException;
import java.net.*;

public class getipof {
public static Inet4Address netd(String url) throws IOException{
	Inet4Address w = null;
	
	return (Inet4Address) w.getByName(url);
}
public static Inet4Address getconicalc(String url) throws IOException{
	Inet4Address w = null;
	url = w.getCanonicalHostName();
	return w;
}
public static Inet4Address getserver(String url) throws IOException{
	Inet4Address w = null;
	url=w.getHostAddress();
	return w;
}



public static void main(String[] args) throws IOException{
	Scanner scanner = new Scanner(System.in);
	System.out.println("please enter the site you want to get an ip for: ");
	String url = scanner.nextLine();
	System.out.println("Your site ip address and name is : "+netd(url));
}
}
