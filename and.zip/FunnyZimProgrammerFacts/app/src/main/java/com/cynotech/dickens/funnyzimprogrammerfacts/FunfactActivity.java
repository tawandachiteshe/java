package com.cynotech.dickens.funnyzimprogrammerfacts;

import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.*;
import android.view.View;

import java.util.Random;


public class FunfactActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funfact);
        final TextView factText= (TextView) findViewById(R.id.factText);
        Button buttonfact = (Button) findViewById(R.id.shownextfact);
        final RelativeLayout relativeLayout = (RelativeLayout)findViewById(R.id.fanactivity);
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] facts = {"If you are struck by lightning, your skin will be heated to 28,000 degrees Centigrade, hotter than the surface of the Sun.",
                        "If you trace your family tree back 25 generations, you will have 33,554,432 direct ancestors  assuming no incest was involved.",
                        "The average distance between the stars in the sky is 20 million miles.",
                        "It would take a modern spaceship 70,000 years to get to the nearest star to earth.",
                        "An asteroid wiped out every single dinosaur in the world, but not a single species of toad or salamander was affected. No one knows why, nor why the crocodiles and tortoises survived.",
                        "If you dug a well to the centre of the Earth, and dropped a brick in it, it would take 45 minutes to get to the bottom \u2013 4,000 miles down.",
                        "Your body sheds 10 billion flakes of skin every day.",
                        "The Earth weighs 6,500 million million million tons.",
                        "Honey is the only food consumed by humans that doesn\u2019t go off.",
                        "The Hawaiian alphabet has only 12 letters.",
                        "A donkey can sink into quicksand but a mule can\u2019t.",
                        "Every time you sneeze your heart stops a second.",
                        "There are 22 miles more canals in Birmingham UK than in Venice.",
                        "Potato crisps were invented by a Mr Crumm.",
                        "Facetious and abstemious contain all the vowels in their correct order.",
                        "Eskimoes have hundreds of words for snow but none for hello.",
                        "The word \u201cset\u201d has the most definitions in the English language.",
                        "The only 15 letter word that can be spelled without repeating its letters is uncopyrightable.",
                        "Windmills always turn counter-clockwise.",
                        "The \u201cSixth Sick Sheik\u2019s Sixth Sheep\u2019s Sick\u201d is the hardest tongue-twister"
                } ;
                String[] color = {"#39add1",
                        "#3879ab",
                        "#c25975",
                        "#e15258",
                        "#f9845b",
                        "#838cc7",
                        "#7d669e",
                        "#53bbb4",
                        "#51b46d",
                        "#c8ab18",
                        "#637a91",
                        "#f092b8",
                        "#b7c0c7"

                } ;
                Random randomgen = new Random();
                int randomnumber1=randomgen.nextInt(color.length);
                String colors="";
                colors=color[randomnumber1];
                int colo = Color.parseColor(colors);
            String fact ="";

                int randomnumber=randomgen.nextInt(facts.length);



                fact=facts[randomnumber];

                relativeLayout.setBackgroundColor(colo);
                factText.setText(fact);
            }

        };
              buttonfact.setOnClickListener(listener);
        Toast.makeText(this,"app developed by Tawanda Aka ibu",Toast.LENGTH_LONG).show();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_funfact, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
