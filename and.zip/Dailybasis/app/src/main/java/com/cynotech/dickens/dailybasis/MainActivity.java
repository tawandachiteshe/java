package com.cynotech.dickens.dailybasis;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;


public class MainActivity extends ActionBarActivity {

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button butcacl = (Button) findViewById(R.id.buttoncalc);
         final TextView txtview = (TextView) findViewById(R.id.textView2);
         final EditText edttext = (EditText) findViewById(R.id.EditText2);
        final Intent newone = new Intent(getApplicationContext(),MainActivity2Activity.class);
        View.OnLongClickListener onlong = new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                startActivity(newone);
                return true;
            }
        };
        View.OnClickListener listener = new View.OnClickListener() {


            @Override
            public void onClick(View v) {

               int a = Integer.parseInt(edttext.getText().toString());
                if (a==1||a==2) {
                    txtview.setText("REALLY!!! a polygon have three or more sides reenter the number of sides");
                    txtview.setTextSize(12);
                }else {
                    int b=(a-2)*180;
                    txtview.setText(b+"");
                    txtview.setTextSize(32);




                }

            }
        };
        butcacl.setOnClickListener(listener);
       butcacl.setOnLongClickListener(onlong);
    }


}
