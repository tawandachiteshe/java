package filewriter;
import java.io.*;
import java.net.*;
import java.sql.Time;
import java.time.*;
import java.util.*;
public class filewrite {

	private static LocalTime lt;

	public static void main(String[] args) {
		Console console = System.console();

		try {
			ServerSocket ss=new ServerSocket(8989);
			Socket s=ss.accept();
			DataOutputStream dor =new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
			Clock clock=null;
			lt = null;
			
			String str="ibu.txt";
			File file = new File(str);
			file.createNewFile();
			System.out.println("your disk free space is "+file.getFreeSpace()/1024/1024/1024+"GB");
			FileWriter fr = new FileWriter(file);
			byte[] bytes = new byte[4096];
			bytes.equals(file);
			dor.writeUTF(str);
			s.close();
			ss.close();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}

}
