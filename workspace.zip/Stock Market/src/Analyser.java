
public class Analyser {

	public static void main(String[] args) {
		stockMarket sm = new stockMarket();
		Editfiles ed = new Editfiles();
		sm.readStocks();
	

	}

}
