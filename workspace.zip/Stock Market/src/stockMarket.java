import java.io.*;
public class stockMarket {
	private String[][] rcolu ={{""},{""}};
	private BufferedReader bufferedreader= null;
	private String stock="";
	public void readStocks(){
		File file = new File("stocks.csv");
		try {
			FileReader fileReader = new FileReader(file);
			 bufferedreader = new BufferedReader(fileReader);
			 stock = bufferedreader.read()+"";
			while(stock!=null){
				
				rcolu[0][0]=stock;
				System.out.println(rcolu[0][1]);
				stock=bufferedreader.readLine();
			}
			
		} catch (Exception e) {
			System.out.println("can't read from file");
		}
		try {
			bufferedreader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			}
}
