
public class prompter {
 public void returnstocks(){
	 stockMarket stock = new stockMarket();
	 stock.readStocks();
 }
}
