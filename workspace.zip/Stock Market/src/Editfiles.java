import java.io.*;
import java.util.*;


public class Editfiles {
	
	
	public void editStock(){
	File file =new File("stocks.csv");
	String ss="tawanda";
		try {
			BufferedWriter bufr = new BufferedWriter(new FileWriter(file));
			bufr.write(ss);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
	
}
