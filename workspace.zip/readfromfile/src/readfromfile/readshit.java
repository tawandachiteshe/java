package readfromfile;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.net.*;
public class readshit {

	public static void main(String[] args) {
		try{
			int a=3;
			int b =9;
		Socket socket = new Socket("127.0.0.1",8081);
		DataOutputStream dot = new DataOutputStream(socket.getOutputStream());
		dot.write(a);
		dot.write(b);
		socket.close();
		dot.close();
		}catch(Exception ex){
			
		}
		
	}
}
