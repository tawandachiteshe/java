import java.net.*;
import java.io.*;   
public class javait {

	public static void main(String[] args) {
		try{
		ServerSocket server = new ServerSocket(8989);
		Socket s=server.accept();
		//to output data that we had sents
		DataOutputStream dou = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
		//to imput our data
		DataInputStream di = new DataInputStream(new BufferedInputStream(s.getInputStream()));
		byte[] bytes = new byte[4096];
		di.read(bytes);
		System.out.println(bytes);
		FileWriter fw = new FileWriter("C:/Users/ibu.txt");
		FileOutputStream fos = new FileOutputStream("ibu.txt");
		fw.write("ibu.txt");
		fos.write(bytes);
		dou.write(bytes);
		
		server.close();
		s.close();
		fw.write("hello.txt");
		fw.flush();
		dou.close();
		di.close();
		}catch(Exception ex){
			System.out.println(ex);
		}
	}

}
