import java.io.*;
import java.net.*;
public class client{
	
	public void clien(){
		try {
			Socket socket = new Socket("localhost",9999);
			DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
			File file = new File("ibu.txt");
			file.createNewFile();
			dos.writeBytes(file+"");
			dos.close();
			socket.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
}
