import java.net.*;
import java.io.*;
public class server {
	
	public void _server(){
		try{
			File file = new File("ibu.txt");
			byte[] bytes = new byte[1024];
		ServerSocket s = new ServerSocket(9999);
		Socket ss=s.accept();
		DataInputStream di = new DataInputStream(new BufferedInputStream(ss.getInputStream()));
		di.read(bytes);
		ss.close();
		di.close();
		}catch(Exception ex){
			
		}
	}

}