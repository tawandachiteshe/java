import java.rmi.server.ServerCloneException;
import java.util.*;

public class main {

	public static void main(String[] args) {
		
		Scanner ss = new Scanner(System.in);
		System.out.println("choose 1 for client");
		System.out.println("choose 2 for server");
		int a = ss.nextInt();
		switch(a){
		case 1:
			
			server serv = new server();
			serv._server();
			break;
		case 2:
			client cli = new client();
			cli.clien();
			break;
			
			
		}
	}

}
