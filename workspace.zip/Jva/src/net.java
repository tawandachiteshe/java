import java.io.*;
import java.net.*;
public class net {
	

	public static void main(String[] args){
		while(true){
		try{
			
			Console console = System.console();
			String ssw = console.readLine();
		ServerSocket server = new ServerSocket(9000);
		Socket s=server.accept();
		DataOutputStream dow = new DataOutputStream(s.getOutputStream());
		dow.writeUTF(ssw);
		DataInputStream di = new DataInputStream(s.getInputStream());
		String str=di.readUTF();
		dow.close();
		
		server.close();
		System.out.println(str);
		}catch(Exception e){
			System.out.println("port in use");
		}
		}
	}
}
