import java.io.*;
import java.net.*;
public class server {
	
	
	public static void server(){
	
	}
	
	public static void main(String[] args){
		
	}
	
}
