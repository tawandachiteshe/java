import java.io.*;
import java.util.*;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
public class fileinput {
      public File file(String file){
    	  File nfile = new File(file);
    	  
    	  try{
    	  FileInputStream fi = new FileInputStream(nfile);
    	  ZipInputStream zi = new ZipInputStream(fi);
    	  zi.read();
    	  zi.close();
    	  }catch(Exception is){
    		  
    	  }
    	return nfile;
      }
    
}
