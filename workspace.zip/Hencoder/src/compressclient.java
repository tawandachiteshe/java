
public class compressclient {

	public static void main(String[] args) {
		String Sfile = "file.zip";
		fileinput file = new fileinput();
		file.file(Sfile);
		hcoder h= new hcoder(file.toString());
		System.out.println(h.compress(file.toString()));
		System.out.println(h.decompress("100011001011110"));
		
	}

}
