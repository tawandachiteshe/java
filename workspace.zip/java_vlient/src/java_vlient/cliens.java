package java_vlient;

import java.io.Console;
import java.io.DataOutputStream;
import java.net.Socket;

public class cliens {

	public static void main(String[] args) {
		while(true){
		try{	
			Socket s=new Socket("localhost",2001);
			String masse="";	
			Console console = System.console();
			masse=console.readLine();
			DataOutputStream dout=new DataOutputStream(s.getOutputStream());

			dout.writeUTF(masse);
			dout.flush();

			dout.close();
			s.close();

			}catch(Exception e){System.out.println(e);}
			}
	}
	}