package samples;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
public class osoooourcoeoooooooooooooooooooooooooooo {

	public static void main(String[] args) {
		
		
		byte[] bytes = new byte[1024];
		int a=0,b=0,c=0;
		c=a+b;
		try{
			
	ServerSocket server = new ServerSocket(8081);
	Socket socket=server.accept();
	DataInputStream di = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
	
		a = di.readInt();
		b =di.readInt();
		DataOutputStream dot = new DataOutputStream(socket.getOutputStream());
		System.out.println("creating");
	dot.write(c);
	di.close();
	dot.close();
	server.close();
	socket.close();
		}catch(Exception ex){
			
		}
	}

}
