package javaitc;
import java.net.*;
import java.io.*;
public class javaitc {


	public static void main(String[] args) {
		try {
			
			Socket socket = new Socket("127.0.0.1",8989);
			//this is out data input stream to put our file in
			DataInputStream di = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
			//data out for our file to send
			DataOutputStream daw = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
			//here to send our file
			byte[] bytes = new byte[1024];
			di.readUTF();
			
			daw.close();
			di.close();
			socket.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		

	}

}
