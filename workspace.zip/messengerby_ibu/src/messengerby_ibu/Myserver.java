
package messengerby_ibu;

import java.net.*;
import java.io.*;
public class Myserver {
	public void Myserver(){
		
		try{
		ServerSocket ss=new ServerSocket(2001);
		Socket s=ss.accept();//establishes connection 

		DataInputStream dis=new DataInputStream(s.getInputStream());

		String	str=(String)dis.readUTF();
		System.out.println("message= "+str);

		ss.close();

		}catch(Exception e){System.out.println(e);}
		}
	

	}
	

