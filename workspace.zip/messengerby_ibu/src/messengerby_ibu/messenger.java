package messengerby_ibu;

public class messenger {

	public static void main(String[] args) {
		Myserver server = new Myserver();
		server.Myserver();
		
	}

}
