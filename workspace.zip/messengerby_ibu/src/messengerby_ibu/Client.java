package messengerby_ibu;
import java.net.*;
import java.io.*;
public class Client {
	public void Client(){
		try{	
		Socket s=new Socket("localhost",2001);
		String masse="hello bitch";	
		Console console = System.console();
		console.readLine(masse);
		DataOutputStream dout=new DataOutputStream(s.getOutputStream());

		dout.writeUTF(masse);
		dout.flush();

		dout.close();
		s.close();

		}catch(Exception e){System.out.println(e);}
		}
}
