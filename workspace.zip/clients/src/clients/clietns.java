package clients;
import java.io.*;
import java.net.*;
import java.util.Scanner;
public class clietns {

	public static void main(String[] args) {
		while(true){
		try{
		Console console = System.console();
		String ssu= console.readLine();
		Socket socket = new Socket("127.0.0.1",9000);
		DataInputStream di = new DataInputStream(socket.getInputStream());
		System.out.println(di.readUTF());
		DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
		dout.writeUTF(ssu);
		dout.flush();
		di.close();
		socket.close();
		}catch(Exception ex){
			System.out.println("port in use or failed to connect");
		}
		
		}
	}

}
