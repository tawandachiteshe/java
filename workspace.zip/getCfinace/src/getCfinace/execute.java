package getCfinace;

public class execute {

	public static void main(String[] args) {
		resources rse = new resources();
		rse.file();

	}

}
