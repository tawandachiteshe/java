package getCfinace;
import java.io.*;
import java.util.*;
import java.util.zip.*;
public class resources {
	
	
	public void file(){
		Scanner sd = new Scanner(System.in);
		System.out.println("Enter your Choice :" );
		int x=0;
		x=sd.nextInt();
		switch(x){
		case 1:
			System.out.println("u are sick");
			break;
		case 2:
			System.out.println("u are not my type");
			break;
			default:
				System.out.println("U ARE THE MAN");
				System.out.println(num(7,9));
				
		}
	}
public int num(int a,int b){
	return a+b;
}
}
