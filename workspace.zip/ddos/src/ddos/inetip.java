package ddos;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.*;

public class inetip {
   public static String inetid(){
	  try {
		  DataOutputStream dod=null;
		  ServerSocket serversocket = new ServerSocket(8884);
		  dod.writeUTF("shame");
		  
		  Socket s=serversocket.accept();
		  serversocket.accept();
		  DataInputStream di;
		  Socket socket = new Socket("127.0.0.1",8884);
		
		String localmachin="DESKTOP-QI9GVLS";
		byte[] b = new byte[4096];
		int ades = 1921684354;
		 Inet4Address iu = (Inet4Address) Inet4Address.getByName(localmachin);
		 System.out.println();
		System.out.println(iu);
		System.out.println(iu.getCanonicalHostName());
		System.out.println(iu.isReachable(ades));
		
		} catch (Exception e1) {
		
		e1.printStackTrace();
	}
	
	  try {
		System.out.println("");
	} catch (Exception e) {
		
	System.out.println(e);
	}
	  return null;
   }



private static  Inet4Address Inet4Address() {
	Inet4Address a = null;
	return a;
}
}
