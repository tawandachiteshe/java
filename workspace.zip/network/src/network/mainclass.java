package network;

public class mainclass {

	public static void main(String[] args) {
		 network nt = new network();
		System.out.println(nt.getFirstPort("8766"));
		System.out.println(nt.getLastPort("9099"));

	}

}
