import java.io.IOException;
import java.net.*;
public class jas {

	public static void main(String[] args) {
		try {
		URL url=null;
		String facebook="www.facebook.com";
		
			url = new URL(facebook);
		} catch (Exception e) {
			
		
		Inet4Address inet;
		Inet6Address inetc =  null;
		HttpURLConnection htta= new HttpURLConnection(url) {
			
			@Override
			public void connect() throws IOException {
				
				
			}
			
			@Override
			public boolean usingProxy() {
				// TODO Auto-generated method stub
				return false;
			}
			
			@Override
			public void disconnect() {
				// TODO Auto-generated method stub
				
			}
		};
		
		try {
			
		
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}
}
