import java.util.Random;


public class game {
	private String mHangman = "hangman";
	private String mHangman_ = "h";
	
	char guess;
	
	public String setName(String Mhang){
		mHangman = Mhang;
		return Mhang;
	}
	public String Getname(){
		
		return setName(mHangman);
	}
	public void guessName(){
		
		for (char a : Getname().toCharArray() ){
			
		}
	}
	public void pointer(){
		if(isCorrect()==true){
			System.out.println(Getname().indexOf("a"));
			
		}else{
			
		}
	}
		public void textreplacer(){
			Random rand = new Random();
			rand.setSeed(Getname().indexOf(mHangman));
			for(char a : Getname().toCharArray()){
				a= (char)rand.nextInt();
				char b='-';
				a=b;
				if(Getname().indexOf(a)>=0){
					
					
				}
				
		
			}
		}
	
	
	
	public boolean isCorrect(){
		
		boolean is = Getname().contains(mHangman_);
		return is;
	}
}
