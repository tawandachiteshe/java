
public class Hangmain {

	public static void main(String[] args) {
	game hang = new game();
	
	String a = "";
	hang.setName("hangman");
	System.out.println(hang.isCorrect());
	hang.textreplacer();
	hang.pointer();
	
	hang.guessName();

	}

}
