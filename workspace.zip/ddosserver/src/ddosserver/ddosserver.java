package ddosserver;
import java.io.*;
import java.net.*;
public class ddosserver {
	{
	try{
	ServerSocket ss = new ServerSocket(9000);
	
	Socket s=ss.accept();
	DataInputStream di = new DataInputStream(s.getInputStream());
	String ssre = di.readUTF();
	}catch(Exception ex){
		System.out.println(ex);
	}

}
}
