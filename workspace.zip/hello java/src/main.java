import java.io.*;
public class main {

	public static void main(String[] args) {
		Console console = System.console();
		int mainmenu=0;
		console.printf("plis press 6 to continue");
		mainmenu = Integer.parseInt(console.readLine());
		while(mainmenu==6){
		
		console.printf("Press 1 for multiplication\nPress 2 for division \nPress 3 for addition \nPress 4 for substration ");
		int switd = Integer.parseInt(console.readLine());
		
		while(switd<5){
		switch(switd){
		case 1:
		
	     console.printf("enter first no ");
		int a = Integer.parseInt(console.readLine());
		console.printf("enter second no ");
		int b = Integer.parseInt(console.readLine());
		
		console.printf("the multiplaication answer is %s",a*b+"");
		console.printf("press 6 to go back to main menu", mainmenu=Integer.parseInt(console.readLine()));
		
		break;
		case 2:
			
		     console.printf("enter first no ");
			int g = Integer.parseInt(console.readLine());
			console.printf("enter second no ");
			int h = Integer.parseInt(console.readLine());
			
			console.printf("the multiplaication answer is %s",g/h+"");
			console.printf("press 6 to go back to main menu", mainmenu=Integer.parseInt(console.readLine()));
			break;
		case 3:
			
		     console.printf("enter first no ");
			int c = Integer.parseInt(console.readLine());
			console.printf("enter second no ");
			int d = Integer.parseInt(console.readLine());
			
			console.printf("the multiplaication answer is %s",c+d+"");
			console.printf("press 6 to go back to main menu", mainmenu=Integer.parseInt(console.readLine()));
			break;
		case 4:
			
		     console.printf("enter first no ");
			int e = Integer.parseInt(console.readLine());
			console.printf("enter second no ");
			int f = Integer.parseInt(console.readLine());
			
			console.printf("the multiplaication answer is %s",e-f+"");
			console.printf("press 6 to go back to main menu", mainmenu=Integer.parseInt(console.readLine()));
			break;
			default:
				console.printf("many follow my gd instruction");
		}
		}
	}
	}

}
