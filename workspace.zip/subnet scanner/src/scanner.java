import java.awt.datatransfer.*;
import java.net.*;
import java.util.zip.*;
import java.io.*;
public class scanner {
		public Inet4Address gethostaddress(){
			Inet4Address iet=null;
			try {
				 iet=(Inet4Address) Inet4Address.getLocalHost();
			} catch (Exception e) {
				
			}
			
			return iet;
		}
		public enum NetworkInterface{
			Ethernet;

			public static NetworkInterface getNetworkInterfaces() {
				
				return getNetworkInterfaces();
			}
		}
		
		public Inet4Address getother(){
			Inet4Address inet = (Inet4Address) Inet4Address.getLoopbackAddress();	
			return inet;
		}
	o
			
			
		
		
			 {
				
			
		}
}
