
public class Getinfo {
public static void main(String[] args){
	try {
		scanner sc = new scanner();
		System.out.println(sc.gethosts());
		
	} catch (Exception e) {
		
	}
}
}
