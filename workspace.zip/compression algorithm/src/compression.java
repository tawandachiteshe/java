import java.util.zip.*;
import java.io.*;
public class compression {

	public static void main(String[] args) {
		try{
			
			byte[] bytes = new byte[1024];	
			
		String str="ibu.zip";
		File file = new File(str);
		File fi;
		OutputStream od=file.createNewFile();
		ZipOutputStream zo = new ZipOutputStream(od);
		zo.write(bytes);
		ZipFile z=new ZipFile(file);
		System.out.println(z.size());
		
		}catch(Exception ex){
			System.out.println(ex);
		}
	}

}
